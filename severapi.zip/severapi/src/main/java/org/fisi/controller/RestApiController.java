package org.fisi.controller;

import java.util.List;

import org.fisi.data.User;
import org.fisi.service.UserService;
import org.fisi.severapi.CustomErrorType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RequestMapping("/api")
@RestController
public class RestApiController {

	public static final Logger logger =
			LoggerFactory.getLogger(RestApiController.class);
	
	@Autowired
	UserService userService;
	
	@RequestMapping(value="/user",method=RequestMethod.GET)
	public ResponseEntity<List<User>> listAllUsers() {
			logger.info("Mostrando todos los usuarios");
			List<User> users = userService.consulta();
			if(users.isEmpty()) {
			return new ResponseEntity(HttpStatus.NOT_FOUND);
			}
			return new ResponseEntity<List<User>>(users,HttpStatus.OK);
			}

	
	@RequestMapping(value="/user/{id}",method=RequestMethod.GET)
	public ResponseEntity<?> getUser(@PathVariable("id") long id){
			logger.info("Buscando usuario con id de entrada {}",id);
			 User user =userService.consultaPorId(id);
			 if(user == null) {
			 logger.error("usuario con id {} no existe",id);
			 return new ResponseEntity(new CustomErrorType("Usuario con id "+id+" no encontrado"),HttpStatus.NOT_FOUND);
			 }
			 return new ResponseEntity<User>(user,HttpStatus.OK);
			}
}
